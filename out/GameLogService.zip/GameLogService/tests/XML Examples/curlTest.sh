#!/bin/bash

curl -v -F file=@./RU50-209-2013-913051-1739668.xml http://$1/api/events
read -rsp $'Press any key to continue.../n' -n 1 key
curl -v -F file=@./RU50-209-2013-913051-1739672.xml http://$1/api/events
read -rsp $'Press any key to continue.../n' -n 1 key
curl -v -F file=@./RU50-209-2013-913051-1739679.xml http://$1/api/events
read -rsp $'Press any key to continue.../n' -n 1 key
curl -v -F file=@./RU50-209-2013-913051-1739684.xml http://$1/api/events
read -rsp $'Press any key to continue.../n' -n 1 key
curl -v -F file=@./RU50-209-2013-913051-1739692.xml http://$1/api/events
read -rsp $'Press any key to continue.../n' -n 1 key
curl -v -F file=@./RU50-209-2013-913051-1739695.xml http://$1/api/events
read -rsp $'Press any key to continue.../n' -n 1 key
curl -v -F file=@./RU50-209-2013-913051-1739699.xml http://$1/api/events
read -rsp $'Press any key to continue.../n' -n 1 key
curl -v -F file=@./RU50-209-2013-913051-1739703.xml http://$1/api/events
read -rsp $'Press any key to continue.../n' -n 1 key
curl -v -F file=@./RU50-209-2013-913051-1739706.xml http://$1/api/events
read -rsp $'Press any key to continue.../n' -n 1 key
curl -v -F file=@./RU50-209-2013-913051-1739712.xml http://$1/api/events
read -rsp $'Press any key to continue.../n' -n 1 key
curl -v -F file=@./RU50-209-2013-913051-1739714.xml http://$1/api/events
read -rsp $'Press any key to continue.../n' -n 1 key
curl -v -F file=@./RU50-209-2013-913051-1739715.xml http://$1/api/events
read -rsp $'Press any key to continue.../n' -n 1 key
curl -v -F file=@./RU50-209-2013-913051-1739717.xml http://$1/api/events
read -rsp $'Press any key to continue.../n' -n 1 key
curl -v -F file=@./RU50-209-2013-913051-1739722.xml http://$1/api/events
read -rsp $'Press any key to continue.../n' -n 1 key
curl -v -F file=@./RU50-209-2013-913051-1739727.xml http://$1/api/events
read -rsp $'Press any key to continue.../n' -n 1 key
curl -v -F file=@./RU50-209-2013-913051-1739731.xml http://$1/api/events
read -rsp $'Press any key to continue.../n' -n 1 key
curl -v -F file=@./RU50-209-2013-913051-1739735.xml http://$1/api/events
read -rsp $'Press any key to continue.../n' -n 1 key
curl -v -F file=@./RU50-209-2013-913051-1739739.xml http://$1/api/events
read -rsp $'Press any key to continue.../n' -n 1 key
curl -v -F file=@./RU50-209-2013-913051-1739745.xml http://$1/api/events
read -rsp $'Press any key to continue.../n' -n 1 key
curl -v -F file=@./RU50-209-2013-913051-1739756.xml http://$1/api/events
read -rsp $'Press any key to continue.../n' -n 1 key
curl -v -F file=@./RU50-209-2013-913051-1739769.xml http://$1/api/events
read -rsp $'Press any key to continue.../n' -n 1 key
curl -v -F file=@./RU50-209-2013-913051-1739799.xml http://$1/api/events
